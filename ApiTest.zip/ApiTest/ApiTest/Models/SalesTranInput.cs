﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ApiTest.Models
{
    public class SalesTranInput
    {
        public DateTime dashDate { get; set; }
        public string branch { get; set; }
    }
}